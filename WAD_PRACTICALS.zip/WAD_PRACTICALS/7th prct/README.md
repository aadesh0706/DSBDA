for this practical, there is frontend "5th prct" 

first execute same steps as for 5th pract (read README.md of 5th prct)

after running 5th prct
then in 7th prct there is file "server.js"
In that file line 11, put your mongodb atlas uri in ' ' 

Commands:

cd "7th prct"

npm install

npm start