console.log("Static site loaded via Node.js server.");
