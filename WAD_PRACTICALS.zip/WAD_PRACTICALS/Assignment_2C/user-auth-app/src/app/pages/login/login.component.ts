import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms'; // ✅ Import this

@Component({
  selector: 'app-login',
  standalone: true, // ✅ Add this if missing
  imports: [FormsModule], // ✅ Register FormsModule here
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent {
  username = '';
  password = '';

  login() {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    if (user.username === this.username && user.password === this.password) {
      alert('Login successful!');
      localStorage.setItem('loggedIn', 'true');
    } else {
      alert('Invalid credentials');
    }
  }
}
