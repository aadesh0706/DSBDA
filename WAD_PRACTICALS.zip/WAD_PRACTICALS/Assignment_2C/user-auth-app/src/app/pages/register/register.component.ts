import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms'; // ✅ Import this

@Component({
  selector: 'app-register',
  standalone: true, // ✅ Important
  imports: [FormsModule], // ✅ Important
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
})
export class RegisterComponent {
  username = '';
  password = '';

  register() {
    const user = {
      username: this.username,
      password: this.password,
    };
    localStorage.setItem('user', JSON.stringify(user));
    alert('Registration successful!');
  }
}
