import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms'; // ✅ Add this

@Component({
  selector: 'app-profile',
  standalone: true, // ✅ Must be standalone
  imports: [FormsModule], // ✅ Include FormsModule
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css'],
})
export class ProfileComponent {
  username = '';
  email = '';

  ngOnInit() {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    this.username = user.username || '';
    this.email = user.email || '';
  }

  updateProfile() {
    const updatedUser = { username: this.username, email: this.email };
    localStorage.setItem('user', JSON.stringify(updatedUser));
    alert('Profile updated!');
  }
}
