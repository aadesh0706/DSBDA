Note: this is not 5th practical, this is part of 7th practical

cd 5th prct

npm install -g @angular/cli

cd user-auth-app

npm install

ng serve