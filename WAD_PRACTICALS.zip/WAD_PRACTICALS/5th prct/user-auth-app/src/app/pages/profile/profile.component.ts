import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css'],
})
export class ProfileComponent implements OnInit {
  username = '';
  userId: string | null = null;

  constructor(private authService: AuthService, private router: Router) {}

  ngOnInit() {
    const user = this.authService.getUser();
    if (user) {
      this.username = user.username || '';
      this.userId = user._id || null;
    }
  }

  updateProfile() {
    if (!this.userId) {
      alert('User not logged in');
      return;
    }
    const updatedUser = { username: this.username };
    this.authService.updateUser(this.userId, updatedUser).subscribe({
      next: (res) => {
        alert('Profile updated!');
        localStorage.setItem('user', JSON.stringify(res));
      },
      error: (err) => alert('Update failed: ' + err.message),
    });
  }

  deleteProfile() {
    if (!this.userId) {
      alert('User not logged in');
      return;
    }
    this.authService.deleteUser(this.userId).subscribe({
      next: () => {
        alert('User deleted');
        localStorage.removeItem('user');
        this.router.navigate(['/register']);
      },
      error: (err) => alert('Delete failed: ' + err.message),
    });
  }
}
